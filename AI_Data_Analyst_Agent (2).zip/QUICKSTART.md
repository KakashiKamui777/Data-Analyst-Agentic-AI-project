# 🚀 Quick Start Guide - AI Data Analyst Agent

## Get Started in 3 Steps

### Step 1: Install Dependencies (1 minute)

```bash
pip install -r requirements.txt
```

**What's being installed:**
- Streamlit (Web UI)
- Pandas (Data processing)
- Matplotlib & Seaborn (Visualizations)
- Requests (API calls)

### Step 2: Launch the App (30 seconds)

**Option A - Using the script:**
```bash
./run.sh
```

**Option B - Direct command:**
```bash
streamlit run app.py
```

The app will open automatically in your browser at `http://localhost:8501`

### Step 3: Analyze Data (2 minutes)

1. **Upload a dataset** (use `sample_sales_data.csv` or your own CSV)
2. **Click "🚀 Start Autonomous Analysis"**
3. **Watch the AI agent work!**

## Your First Analysis

### Using the Sample Dataset

1. In the sidebar, click "Browse files"
2. Select `sample_sales_data.csv`
3. Preview the data in the expander
4. Click "🚀 Start Autonomous Analysis"
5. Wait 10-20 seconds while the agent:
   - Cleans the data
   - Performs EDA
   - Generates insights
   - Creates visualizations

### What You'll See

The agent will autonomously:
- ✅ Check data quality and missing values
- 📊 Analyze distributions and statistics
- 📈 Identify trends and patterns
- 🎯 Generate business insights
- 💡 Provide actionable recommendations
- 📉 Create relevant charts and graphs

## Asking Questions

Switch to the "💬 Ask Questions" tab and try:

**Simple Questions:**
```
"What are the top 5 products by sales?"
"Show me total revenue by region"
"What's the average profit margin?"
```

**Analysis Questions:**
```
"Which category is most profitable?"
"Show me sales trends over time"
"Are there any seasonal patterns?"
```

**Visualization Requests:**
```
"Create a bar chart of sales by product"
"Show me a correlation heatmap"
"Plot the distribution of profits"
```

## Example Workflow

### Business Analytics Scenario

**Your Dataset:** Sales transactions (like the sample)

**Step 1 - Upload & Preview:**
```
✓ Upload sample_sales_data.csv
✓ See 50 rows × 9 columns
✓ Preview shows Date, Product, Category, Sales, etc.
```

**Step 2 - Autonomous Analysis:**
The agent discovers:
- Electronics category dominates sales (65%)
- North region has highest profit margin (18%)
- Laptops are top revenue generator
- Discount correlation: -0.23 with profit
- 15% spike in sales during February

**Step 3 - Interactive Q&A:**
You ask: *"Which products should we focus on?"*

Agent responds:
- Analyzes profit margins by product
- Creates comparison chart
- Recommends: "Focus on Laptops and Monitors - highest margins and steady demand"
- Suggests reducing discounts on premium items

**Step 4 - Deep Dive:**
You ask: *"Show me the trend for Laptop sales"*

Agent:
- Filters data for Laptops
- Creates time series plot
- Identifies growth pattern
- Notes: "23% month-over-month growth"

## Tips for Best Results

### Dataset Preparation

**✅ Good CSV format:**
- Headers in first row
- Consistent data types per column
- Dates in standard format (YYYY-MM-DD)
- No merged cells

**❌ Avoid:**
- Multiple header rows
- Mixed data types in columns
- Special characters in column names
- Empty rows/columns

### Asking Effective Questions

**Be Specific:**
- ❌ "Tell me about the data"
- ✅ "What are the top 3 categories by revenue?"

**Request Visualizations:**
- ❌ "Analyze sales"
- ✅ "Create a line chart showing sales trends by month"

**Follow Up:**
- Build on previous answers
- Ask for deeper analysis
- Request different angles

## Common Use Cases

### 1. Sales Analysis
```
Upload: sales_data.csv
Ask:
- "What's our revenue by product category?"
- "Show me monthly sales trends"
- "Which region underperforms?"
- "Create a funnel visualization"
```

### 2. Customer Analytics
```
Upload: customer_data.csv
Ask:
- "Segment customers by purchase behavior"
- "What's the churn rate?"
- "Show me customer lifetime value distribution"
- "Which segments are most profitable?"
```

### 3. Marketing Performance
```
Upload: campaign_data.csv
Ask:
- "Compare ROI across campaigns"
- "Show me conversion rates by channel"
- "Which ads perform best?"
- "Create a heatmap of engagement"
```

### 4. Financial Review
```
Upload: financial_data.csv
Ask:
- "Show me revenue vs expenses over time"
- "What are the cost drivers?"
- "Analyze profit margins by product line"
- "Identify budget variances"
```

## Troubleshooting

### App Won't Start
```bash
# Check Python version (need 3.8+)
python3 --version

# Reinstall dependencies
pip install -r requirements.txt --upgrade
```

### File Upload Fails
- Check CSV encoding (UTF-8 recommended)
- Verify file isn't corrupted
- Try exporting from Excel: "Save As > CSV (UTF-8)"

### Analysis Doesn't Complete
- Check dataset size (very large files may timeout)
- Verify data quality (extreme outliers can cause issues)
- Try a smaller sample first

### Charts Not Showing
- Refresh the page
- Check browser console for errors
- Verify outputs/ directory exists

## Next Steps

### Explore the Code

**app.py** - Understand the UI
- See how tabs are structured
- Learn session state management
- Customize the interface

**agent_core.py** - Study the agent
- See how prompts are built
- Understand code execution
- Extend capabilities

**ARCHITECTURE.md** - Deep dive
- Full system design
- Data flow diagrams
- Extension points

### Customize the Agent

**Add New Analysis Types:**
Edit the prompt in `agent_core.py` to include:
- Time series forecasting
- Clustering analysis
- Hypothesis testing
- Machine learning suggestions

**Enhance Visualizations:**
Add libraries like Plotly for interactive charts:
```python
exec_globals['plotly'] = __import__('plotly.express')
```

**Export Reports:**
Generate PDF summaries of analysis:
```python
def export_pdf(results):
    # Use reportlab or weasyprint
    # Include charts and insights
```

## Learning Resources

### Understanding Agentic AI
- Autonomous decision-making
- Dynamic tool selection
- Iterative reasoning
- Natural language interaction

### Technologies Used
- **Streamlit:** [docs.streamlit.io](https://docs.streamlit.io)
- **Pandas:** [pandas.pydata.org](https://pandas.pydata.org)
- **Claude API:** [docs.anthropic.com](https://docs.anthropic.com)

### Extending the Project
- Add database connectivity
- Implement user authentication
- Schedule automated reports
- Deploy to production

## Getting Help

**Test the setup:**
```bash
python3 test_agent.py
```

This runs component tests and reports any issues.

**Common Questions:**

Q: *Can I use my own API key?*
A: This environment is pre-configured, but for deployment you'd add:
```python
headers = {"X-API-Key": "your-key", ...}
```

Q: *How large can my dataset be?*
A: Limited by available RAM. For very large files, sample first:
```python
df = pd.read_csv(file, nrows=10000)
```

Q: *Can I analyze multiple files?*
A: Currently single-file. Future enhancement:
- Concatenate files
- Join datasets
- Multi-table analysis

---

## Ready to Analyze!

You're all set! The AI Data Analyst Agent is ready to:
- 🤖 Autonomously analyze your data
- 📊 Generate meaningful insights
- 💬 Answer your questions
- 📈 Create beautiful visualizations

**Start with the sample dataset, then bring your own data!**

Questions? Check ARCHITECTURE.md for technical details or README.md for comprehensive documentation.

Happy analyzing! 🎉
