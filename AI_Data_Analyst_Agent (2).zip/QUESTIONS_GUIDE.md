# 💬 What to Ask the AI Agent - Ready-to-Use Questions

## 🎯 Copy-Paste Questions for Instant Results

Here are **real questions** you can ask right now in the "Ask Questions" tab. Just copy and paste!

---

## 📊 For the Sample Sales Dataset

### **Quick Overview Questions**

```
What's in this dataset?
```

```
How many rows and columns are in the data?
```

```
What are all the column names?
```

```
Show me the first 10 rows
```

```
Are there any missing values?
```

---

### **Statistical Questions**

```
What's the total sales?
```

```
What's the average sales value?
```

```
What's the median profit?
```

```
What's the highest and lowest discount given?
```

```
Calculate the average profit margin
```

```
What's the total quantity sold?
```

```
Show me summary statistics for all numeric columns
```

---

### **Top/Bottom Rankings**

```
What are the top 5 products by sales?
```

```
Which product has the highest profit?
```

```
Show me the top 3 regions by revenue
```

```
What are the bottom 5 products by quantity sold?
```

```
Which customer type generates the most revenue?
```

```
Rank all categories by total profit
```

```
What are the top 10 most profitable transactions?
```

---

### **Comparison Questions**

```
Compare sales between North and South regions
```

```
Which category is more profitable: Electronics or Furniture?
```

```
Compare Premium vs Regular customer purchases
```

```
What's the difference in average discount between regions?
```

```
Which region has the highest profit margin?
```

```
Compare sales in January vs February
```

---

### **Trend & Time-Based Questions**

```
Show me sales trends over time
```

```
Create a line graph of daily sales
```

```
What's the sales trend for Laptops only?
```

```
Show me profit trends by week
```

```
Are sales increasing or decreasing over time?
```

```
What day had the highest sales?
```

```
Show me monthly revenue comparison
```

---

### **Visualization Requests**

```
Create a bar chart of sales by product
```

```
Show me a pie chart of category distribution
```

```
Make a scatter plot of sales vs profit
```

```
Create a histogram of discount values
```

```
Show me a box plot of profit by region
```

```
Generate a correlation heatmap
```

```
Create a line graph with both sales and profit
```

```
Make a bar chart comparing regions
```

---

### **Relationship & Correlation Questions**

```
Is there a relationship between discount and profit?
```

```
Do higher discounts lead to more sales?
```

```
What's the correlation between quantity and profit?
```

```
Show me how price affects sales volume
```

```
Are sales and profit correlated?
```

```
Which variables are most correlated?
```

---

### **Filtering & Specific Analysis**

```
Show me only Electronics sales
```

```
What are the sales for Premium customers only?
```

```
Filter data for North region and show total sales
```

```
Show me all Laptop transactions
```

```
What are sales above $1000?
```

```
Show me transactions with discounts over 10%
```

```
Analyze only Furniture category
```

---

### **Business Insights Questions**

```
Which product should we focus on?
```

```
What's driving our profit?
```

```
Which region is underperforming?
```

```
Are our discounts effective?
```

```
What's our most profitable customer segment?
```

```
Which products have the best profit margins?
```

```
Where should we increase inventory?
```

---

### **Distribution & Pattern Questions**

```
What's the distribution of sales values?
```

```
Show me the distribution of discounts
```

```
Are there any outliers in profit?
```

```
What's the typical order value?
```

```
Show me the range of quantities sold
```

```
Is the data normally distributed?
```

---

### **Complex Multi-Part Questions**

```
Show me the top 3 products by sales and create a chart
```

```
Calculate profit margin by region and visualize it
```

```
Find the correlation between discount and profit, then show a scatter plot
```

```
Compare Electronics and Furniture sales trends over time
```

```
Show me sales by region and highlight the best performer
```

```
Analyze profit by customer type and create a comparison chart
```

---

## 🎨 Visualization-Specific Requests

### **Bar Charts**

```
Create a bar chart showing total sales by category
```

```
Make a horizontal bar chart of profit by product
```

```
Show me a grouped bar chart of sales by region and customer type
```

---

### **Line Graphs**

```
Create a line graph of sales over time
```

```
Show me multiple lines comparing different products over time
```

```
Make a line chart with both revenue and profit
```

---

### **Scatter Plots**

```
Create a scatter plot of quantity vs profit with a trend line
```

```
Show me sales vs discount in a scatter plot
```

```
Make a scatter plot colored by category
```

---

### **Histograms**

```
Show me a histogram of profit with 30 bins
```

```
Create a histogram of sales values
```

```
Make a histogram of discount distribution
```

---

### **Heatmaps**

```
Create a correlation heatmap of all numeric columns
```

```
Show me a heatmap of relationships between sales, profit, and discount
```

---

## 💡 Follow-Up Questions (After Getting Initial Answer)

After the agent gives you an answer, try these follow-ups:

```
Show me that as a bar chart
```

```
Now filter that by Premium customers only
```

```
Create a visualization for that
```

```
What about the opposite - show me the bottom 5
```

```
Can you break that down by region?
```

```
Now show me the trend over time
```

```
Compare that to Furniture category
```

```
What's the percentage distribution?
```

---

## 🎯 Questions by Skill Level

### **Beginner (Start Here)**

1. `What's in this dataset?`
2. `What's the total sales?`
3. `Show me the top 5 products`
4. `Create a bar chart of sales by category`
5. `Are there any missing values?`

### **Intermediate**

1. `What's the correlation between discount and profit?`
2. `Compare sales across all regions`
3. `Show me sales trends over time with a line graph`
4. `Which customer type is most profitable?`
5. `Create a scatter plot of sales vs quantity`

### **Advanced**

1. `Analyze profit margins by region and identify underperformers`
2. `Show me the relationship between all numeric variables in a heatmap`
3. `Compare Electronics vs Furniture sales trends and create visualizations`
4. `Find outliers in profit and explain what makes them unusual`
5. `Calculate ROI for different discount levels and recommend optimal strategy`

---

## 🚀 Complete Example Workflow

Here's a full conversation you can have with the agent:

### **Step 1: Overview**
```
What's in this dataset?
```
*Agent explains the data structure*

### **Step 2: Quick Stats**
```
What's the total sales and average profit?
```
*Agent provides numbers*

### **Step 3: Top Performers**
```
What are the top 5 products by sales?
```
*Agent shows list with values*

### **Step 4: Visualize**
```
Create a bar chart for those top 5 products
```
*Agent generates bar chart*

### **Step 5: Deep Dive**
```
Show me the sales trend for the #1 product over time
```
*Agent creates line graph*

### **Step 6: Analysis**
```
Is there a relationship between discount and profit?
```
*Agent shows correlation and scatter plot*

### **Step 7: Insights**
```
Based on this data, which region should we focus on?
```
*Agent provides recommendation*

---

## 🎓 Pro Tips for Better Questions

### ✅ **DO - Good Questions**

```
✓ "Show me top 5 products by sales"
✓ "Create a bar chart of profit by region"
✓ "What's the correlation between X and Y?"
✓ "Compare Electronics and Furniture categories"
✓ "Filter by Premium customers and show total revenue"
```

### ❌ **DON'T - Vague Questions**

```
✗ "Tell me about the data" (too broad)
✗ "Show me stuff" (not specific)
✗ "Make it better" (unclear what to improve)
✗ "Analyze" (needs more detail)
```

### 💡 **How to Improve Vague Questions**

**Instead of:** "Analyze sales"
**Ask:** "Show me total sales by region and create a bar chart"

**Instead of:** "Show trends"
**Ask:** "Create a line graph of sales trends over time"

**Instead of:** "Find patterns"
**Ask:** "What's the correlation between discount and profit?"

---

## 🔥 Most Popular Questions to Start With

Copy these 10 questions for immediate results:

```
1. What are the top 5 products by sales?

2. Show me sales trends over time

3. Create a bar chart of sales by category

4. Which region has the highest profit?

5. Is there a relationship between discount and profit?

6. Compare Premium vs Regular customer sales

7. Show me a histogram of profit distribution

8. What's the average sales by product?

9. Create a correlation heatmap

10. Which products should we focus on and why?
```

---

## 🎯 Questions for Specific Business Goals

### **Goal: Increase Revenue**
```
- What are our highest revenue products?
- Which customer segment spends the most?
- Show me revenue trends - are we growing?
- Which region has untapped potential?
- What's our average transaction value?
```

### **Goal: Improve Profitability**
```
- Which products have the best profit margins?
- Are discounts hurting our profitability?
- Show me profit by customer type
- Which transactions are most profitable?
- Where are we losing money?
```

### **Goal: Optimize Inventory**
```
- What are the fastest-moving products?
- Show me quantity sold by product
- Which items have low sales volume?
- What's the sales distribution by category?
- Which products should we stock more of?
```

### **Goal: Regional Strategy**
```
- Compare sales across all regions
- Which region is underperforming?
- Show me profit margin by region
- What products sell best in each region?
- Where should we expand?
```

---

## 📝 Template Questions

Use these templates and fill in your specifics:

```
What's the [metric] for [category]?
Example: What's the total sales for Electronics?

Show me [metric] by [dimension]
Example: Show me profit by region

Create a [chart type] of [metric] by [dimension]
Example: Create a bar chart of sales by product

Compare [A] vs [B] in terms of [metric]
Example: Compare North vs South in terms of profit

What's the relationship between [X] and [Y]?
Example: What's the relationship between quantity and discount?

Show me the top [N] [things] by [metric]
Example: Show me the top 10 customers by revenue
```

---

## 🎉 Ready to Start!

**Easiest Way to Begin:**

1. Upload `sample_sales_data.csv`
2. Go to "💬 Ask Questions" tab
3. Copy this question:
   ```
   What are the top 5 products by sales?
   ```
4. Paste and press Enter
5. Watch the magic! 🎊

**Then try:**
```
Create a bar chart for those products
```

**And then:**
```
Show me the sales trend over time
```

You're now having a conversation with your data! 🚀

---

## 💬 Remember

- The agent understands natural language
- You can ask follow-up questions
- Request visualizations anytime
- Be specific for best results
- The agent remembers context

**Start simple, then get more complex as you explore!**
