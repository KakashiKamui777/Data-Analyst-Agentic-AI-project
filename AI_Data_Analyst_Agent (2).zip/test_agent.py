#!/usr/bin/env python3
"""
Test script to verify the AI Data Analyst Agent components
"""

import pandas as pd
import os
import sys

def test_imports():
    """Test that all required packages are available"""
    print("🔍 Testing imports...")
    
    try:
        import streamlit
        print("  ✓ Streamlit")
    except ImportError:
        print("  ✗ Streamlit - FAILED")
        return False
    
    try:
        import pandas
        print("  ✓ Pandas")
    except ImportError:
        print("  ✗ Pandas - FAILED")
        return False
    
    try:
        import matplotlib
        print("  ✓ Matplotlib")
    except ImportError:
        print("  ✗ Matplotlib - FAILED")
        return False
    
    try:
        import seaborn
        print("  ✓ Seaborn")
    except ImportError:
        print("  ✗ Seaborn - FAILED")
        return False
    
    try:
        import requests
        print("  ✓ Requests")
    except ImportError:
        print("  ✗ Requests - FAILED")
        return False
    
    return True

def test_sample_data():
    """Test loading the sample dataset"""
    print("\n📊 Testing sample dataset...")
    
    try:
        df = pd.read_csv('sample_sales_data.csv')
        print(f"  ✓ Loaded {len(df)} rows × {len(df.columns)} columns")
        print(f"  ✓ Columns: {', '.join(df.columns[:5])}...")
        return True
    except Exception as e:
        print(f"  ✗ Failed to load sample data: {e}")
        return False

def test_agent_core():
    """Test that agent_core module loads"""
    print("\n🤖 Testing agent core...")
    
    try:
        import agent_core
        print("  ✓ Agent core module loaded")
        
        # Check functions exist
        if hasattr(agent_core, 'run_analysis_agent'):
            print("  ✓ run_analysis_agent function found")
        else:
            print("  ✗ run_analysis_agent function missing")
            return False
        
        if hasattr(agent_core, 'answer_question'):
            print("  ✓ answer_question function found")
        else:
            print("  ✗ answer_question function missing")
            return False
        
        return True
    except Exception as e:
        print(f"  ✗ Failed to load agent_core: {e}")
        return False

def test_app_structure():
    """Test that app.py exists and is structured correctly"""
    print("\n📱 Testing app structure...")
    
    if not os.path.exists('app.py'):
        print("  ✗ app.py not found")
        return False
    
    print("  ✓ app.py exists")
    
    with open('app.py', 'r') as f:
        content = f.read()
        
        required = [
            'st.set_page_config',
            'st.title',
            'st.file_uploader',
            'agent_core'
        ]
        
        for item in required:
            if item in content:
                print(f"  ✓ Contains {item}")
            else:
                print(f"  ✗ Missing {item}")
                return False
    
    return True

def main():
    """Run all tests"""
    print("=" * 50)
    print("🧪 AI Data Analyst Agent - Component Tests")
    print("=" * 50)
    print()
    
    results = []
    
    results.append(("Imports", test_imports()))
    results.append(("Sample Data", test_sample_data()))
    results.append(("Agent Core", test_agent_core()))
    results.append(("App Structure", test_app_structure()))
    
    print("\n" + "=" * 50)
    print("📋 Test Summary")
    print("=" * 50)
    
    all_passed = True
    for name, passed in results:
        status = "✅ PASSED" if passed else "❌ FAILED"
        print(f"{name:20} {status}")
        if not passed:
            all_passed = False
    
    print("=" * 50)
    
    if all_passed:
        print("\n🎉 All tests passed! The agent is ready to run.")
        print("\nTo start the application, run:")
        print("  ./run.sh")
        print("  or")
        print("  streamlit run app.py")
        return 0
    else:
        print("\n⚠️  Some tests failed. Please check the errors above.")
        return 1

if __name__ == "__main__":
    sys.exit(main())
