# 🚀 VS Code Deployment Guide - AI Data Analyst Agent

## Quick Setup & Run in VS Code

### Step 1: Extract and Open Project

```bash
# Extract the zip file
unzip AI_Data_Analyst_Agent.zip

# Navigate to the folder
cd AI_Data_Analyst_Agent

# Open in VS Code
code .
```

### Step 2: Set Up Python Environment

**Open VS Code Terminal** (`` Ctrl+` `` or View > Terminal)

```bash
# Create virtual environment
python -m venv venv

# Activate virtual environment
# On Windows:
venv\Scripts\activate

# On macOS/Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### Step 3: Run the Application

```bash
# Run the Streamlit app
streamlit run app.py
```

**That's it!** The app will automatically open in your browser at `http://localhost:8501`

---

## 🎯 Alternative: One-Command Setup

Just run the included script:

```bash
# On macOS/Linux:
chmod +x run.sh
./run.sh

# On Windows (PowerShell):
streamlit run app.py
```

---

## 📝 VS Code Tips

### Recommended Extensions

Install these VS Code extensions for better experience:

1. **Python** (Microsoft)
2. **Pylance** (Microsoft)
3. **Jupyter** (optional, for notebooks)

### Using VS Code Terminal

1. Open Terminal: `` Ctrl+` `` (or `` Cmd+` `` on Mac)
2. Run commands directly in the integrated terminal
3. App will run and show output in the terminal

### Stopping the App

Press `Ctrl+C` in the terminal where Streamlit is running

---

## 🔧 Troubleshooting

### Python Not Found
```bash
# Check Python installation
python --version
# or
python3 --version

# If not installed, download from python.org
```

### Port Already in Use
```bash
# Run on different port
streamlit run app.py --server.port 8502
```

### Module Not Found
```bash
# Make sure virtual environment is activated
# You should see (venv) in your terminal prompt

# Reinstall dependencies
pip install -r requirements.txt
```

---

## 📊 Quick Test

1. App opens at `http://localhost:8501`
2. Click **"Browse files"** in sidebar
3. Upload **`sample_sales_data.csv`**
4. Click **"🚀 Start Autonomous Analysis"**
5. Watch the AI agent work! 🤖

---

## 🎉 You're Done!

Your AI Data Analyst Agent is now running locally in VS Code!

**Next Steps:**
- Try the sample dataset
- Upload your own CSV files
- Ask questions in the Q&A tab
- Explore the generated insights and charts
