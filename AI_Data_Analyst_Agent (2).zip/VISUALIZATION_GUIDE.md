# 📊 Interactive Visualizations Guide

## New Feature: Interactive Visualization Tab

The AI Data Analyst Agent now includes a **dedicated Interactive Visualizations tab** that lets you create custom charts without writing any code!

---

## 🎨 Available Chart Types

### 1. 📊 Bar Chart
**Best for:** Comparing categories, showing totals by group

**How to use:**
1. Select **X-axis** (category column like Product, Region, Category)
2. Select **Y-axis** (numeric column like Sales, Profit, Quantity)
3. Choose **Aggregation** (sum, mean, count, median, min, max)
4. Click "Generate Bar Chart"

**Example Use Cases:**
- Total sales by product category
- Average profit by region
- Number of transactions by customer type
- Maximum discount by product

---

### 2. 📈 Line Graph
**Best for:** Showing trends over time, comparing multiple metrics

**How to use:**
1. Select **X-axis** (usually Date or Time column)
2. Select **Y-axis** (one or more numeric columns)
3. Click "Generate Line Graph"

**Example Use Cases:**
- Sales trends over time
- Compare revenue vs profit over months
- Track multiple product sales simultaneously
- Monitor KPI changes

**Pro Tip:** Select multiple Y-axis columns to compare trends side-by-side!

---

### 3. 📊 Histogram
**Best for:** Understanding data distribution, identifying patterns

**How to use:**
1. Select **Column** (any numeric column)
2. Adjust **Number of Bins** (5-100, default 30)
3. Toggle **Show KDE** for smooth distribution curve
4. Click "Generate Histogram"

**What you get:**
- Visual distribution of values
- Automatic statistics (mean, median, std dev, count)
- KDE curve showing probability density

**Example Use Cases:**
- Distribution of order values
- Age distribution of customers
- Price range analysis
- Identify outliers visually

---

### 4. 🔵 Scatter Plot
**Best for:** Finding relationships between two variables

**How to use:**
1. Select **X-axis** (numeric column)
2. Select **Y-axis** (numeric column)
3. Optionally **Color by** category for segmentation
4. Toggle **Show Trend Line** to see correlation
5. Click "Generate Scatter Plot"

**What you get:**
- Visual correlation between variables
- Correlation coefficient
- Optional trend line
- Color-coded categories

**Example Use Cases:**
- Sales vs Discount relationship
- Quantity vs Profit analysis
- Price vs Customer satisfaction
- Identify clusters in data

---

### 5. 📦 Box Plot
**Best for:** Identifying outliers, comparing distributions across groups

**How to use:**
1. Select **Value Column** (numeric data to analyze)
2. Optionally **Group by** a category
3. Click "Generate Box Plot"

**What it shows:**
- Median (middle line)
- Quartiles (box boundaries)
- Outliers (dots outside whiskers)
- Distribution comparison across groups

**Example Use Cases:**
- Sales distribution by region
- Profit ranges by product category
- Identify unusual transactions
- Compare performance across segments

---

### 6. 🥧 Pie Chart
**Best for:** Showing proportions and percentages

**How to use:**
1. Select **Category Column**
2. Choose **Top N Categories** to display (3-20)
3. Click "Generate Pie Chart"

**Example Use Cases:**
- Market share by product
- Revenue distribution by region
- Customer type breakdown
- Category contribution to total

**Pro Tip:** Limit to top 10 categories for clarity!

---

### 7. 🔥 Heatmap
**Best for:** Visualizing correlations between multiple variables

**How to use:**
1. Select columns to include (or use all numeric columns)
2. Click "Generate Heatmap"

**What it shows:**
- Correlation values (-1 to +1)
- Color coding (red = positive, blue = negative)
- Strength of relationships

**Example Use Cases:**
- Find which factors affect sales most
- Identify multicollinearity
- Discover hidden patterns
- Feature selection for analysis

**Reading the heatmap:**
- **+1.0** (dark red): Perfect positive correlation
- **0.0** (white): No correlation
- **-1.0** (dark blue): Perfect negative correlation

---

### 8. 📊 Area Chart
**Best for:** Showing cumulative totals, part-to-whole over time

**How to use:**
1. Select **X-axis** (time or sequence)
2. Select **Y-axis** (one or more metrics)
3. Toggle **Stacked Area** for cumulative view
4. Click "Generate Area Chart"

**Example Use Cases:**
- Cumulative revenue over time
- Multiple product sales stacked
- Resource allocation visualization
- Growth trends

---

## 💡 Quick Suggestions Feature

At the bottom of the Visualization tab, you'll find three quick suggestion buttons:

### 📊 Column Distribution
Click to get suggestions for exploring your data's distribution using histograms.

### 📈 Trends Over Time
Automatically detects date/time columns and suggests line graph configurations.

### 🔥 Correlations
Quick access to generate a correlation heatmap of all numeric columns.

---

## 🎯 Visualization Workflow

### Step 1: Upload Your Data
Upload a CSV file in the sidebar.

### Step 2: Choose Your Chart
Navigate to the **"📊 Interactive Visualizations"** tab.

### Step 3: Configure Settings
- Select chart type from dropdown
- Choose appropriate columns
- Adjust parameters (bins, aggregation, etc.)

### Step 4: Generate
Click the "Generate" button to create your visualization.

### Step 5: Analyze
The chart appears with relevant statistics and insights.

---

## 📋 Best Practices

### For Bar Charts:
✅ Use for categorical comparisons
✅ Limit categories to 10-15 for readability
✅ Use aggregation wisely (sum for totals, mean for averages)

### For Line Graphs:
✅ Sort X-axis chronologically for time series
✅ Don't plot too many lines (3-5 max)
✅ Use different colors for clarity

### For Histograms:
✅ Start with 30 bins, adjust as needed
✅ Use KDE for smooth distributions
✅ Check statistics for numerical insights

### For Scatter Plots:
✅ Look for patterns (linear, clustered, random)
✅ Use color coding to reveal hidden segments
✅ Enable trend line to quantify relationships

### For Heatmaps:
✅ Focus on strong correlations (|r| > 0.5)
✅ Select relevant columns only
✅ Use for feature selection in analysis

---

## 🔍 Example Analysis Workflow

### Scenario: Sales Data Analysis

**Step 1: Overview**
- Start with **Pie Chart** to see category distribution
- Use **Bar Chart** for sales by region

**Step 2: Trends**
- Create **Line Graph** for sales over time
- Compare multiple products simultaneously

**Step 3: Relationships**
- Generate **Scatter Plot** for price vs quantity
- Add **Heatmap** to find all correlations

**Step 4: Distribution**
- Use **Histogram** for profit distribution
- Create **Box Plot** grouped by region to compare

**Step 5: Deep Dive**
- Generate **Area Chart** for cumulative sales
- Use **Box Plot** to identify outliers

---

## 🎨 Customization Tips

### Colors
Charts automatically use pleasing color palettes from Seaborn's "husl" palette.

### Size
All charts are optimized for viewing at various screen sizes.

### Export
Right-click any chart to save as an image (PNG).

### Interactivity
While charts are static (matplotlib), they're high-resolution and publication-ready.

---

## 🚀 Advanced Features

### Multiple Metrics
Line graphs and area charts support multiple Y-axis selections for comparison.

### Dynamic Statistics
Histograms automatically show mean, median, standard deviation, and count.

### Correlation Values
Scatter plots display the correlation coefficient automatically.

### Smart Defaults
The app intelligently suggests appropriate columns based on data types.

---

## 🆚 When to Use Which Chart

| Question | Chart Type |
|----------|-----------|
| What's the breakdown by category? | Pie Chart or Bar Chart |
| How has this changed over time? | Line Graph or Area Chart |
| Are these two things related? | Scatter Plot or Heatmap |
| What's the typical range? | Box Plot or Histogram |
| Are there any outliers? | Box Plot |
| What's the distribution shape? | Histogram |
| Which categories compare how? | Bar Chart |
| What are all the correlations? | Heatmap |

---

## 💬 Integration with AI Agent

The visualization tab works seamlessly with the AI Agent:

1. **Agent Analysis Tab**: Agent creates automated visualizations
2. **Interactive Visualizations Tab**: You create custom charts
3. **Ask Questions Tab**: Request specific charts via natural language

**Example:**
- Agent might create a correlation heatmap during analysis
- You can recreate it with different columns in the Visualization tab
- You can ask "show me a scatter plot of sales vs profit" in Q&A

---

## 🎓 Learning Resources

### Understanding Chart Types:
- **Bar Chart**: Categorical comparisons
- **Line Graph**: Trends and changes
- **Histogram**: Frequency distributions
- **Scatter Plot**: Relationships and correlations
- **Box Plot**: Statistical summaries
- **Pie Chart**: Proportions
- **Heatmap**: Multiple correlations
- **Area Chart**: Cumulative values

### Statistical Concepts:
- **Correlation**: Measures relationship strength (-1 to +1)
- **Distribution**: How data values are spread
- **Outliers**: Unusual values outside normal range
- **Quartiles**: Data divided into four equal parts
- **Trend**: General direction of change over time

---

## 🎉 Start Visualizing!

The Interactive Visualizations tab gives you powerful tools to explore your data visually. Combine it with the AI Agent's autonomous analysis and natural language Q&A for comprehensive data insights!

**Pro Tip:** Start with the Agent Analysis to get an overview, then use Interactive Visualizations to dive deeper into specific areas of interest!
