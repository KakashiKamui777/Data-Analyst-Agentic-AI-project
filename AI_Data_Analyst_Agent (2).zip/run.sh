#!/bin/bash

echo "🤖 AI Data Analyst Agent"
echo "========================"
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed. Please install Python 3.8 or higher."
    exit 1
fi

echo "✓ Python found: $(python3 --version)"
echo ""

# Install dependencies
echo "📦 Installing dependencies..."
pip install -q -r requirements.txt

if [ $? -eq 0 ]; then
    echo "✓ Dependencies installed successfully"
else
    echo "❌ Failed to install dependencies"
    exit 1
fi

echo ""
echo "🚀 Starting AI Data Analyst Agent..."
echo ""
echo "The application will open in your browser automatically."
echo "If not, navigate to: http://localhost:8501"
echo ""
echo "📊 Sample dataset available: sample_sales_data.csv"
echo ""
echo "Press Ctrl+C to stop the server"
echo "================================"
echo ""

# Run Streamlit
streamlit run app.py
