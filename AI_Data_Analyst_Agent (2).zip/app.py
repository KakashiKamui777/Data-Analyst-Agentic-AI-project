import streamlit as st
import pandas as pd
import json
import base64
from io import StringIO
import os
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from datetime import datetime

# Page configuration
st.set_page_config(
    page_title="AI Data Analyst Agent",
    page_icon="🤖",
    layout="wide"
)

# Title and description
st.title("🤖 AI Data Analyst Agent")
st.markdown("""
Upload your dataset and let the AI agent autonomously:
- Clean and preprocess data
- Perform exploratory data analysis (EDA)
- Generate insights
- Create visualizations
- Answer your questions
""")

# Initialize session state
if 'messages' not in st.session_state:
    st.session_state.messages = []
if 'dataset' not in st.session_state:
    st.session_state.dataset = None
if 'analysis_complete' not in st.session_state:
    st.session_state.analysis_complete = False
if 'analysis_results' not in st.session_state:
    st.session_state.analysis_results = None

# Sidebar for dataset upload
with st.sidebar:
    st.header("📊 Dataset Upload")
    
    uploaded_file = st.file_uploader(
        "Upload CSV file",
        type=['csv'],
        help="Upload a CSV file for analysis"
    )
    
    if uploaded_file is not None:
        try:
            df = pd.read_csv(uploaded_file)
            st.session_state.dataset = df
            st.success(f"✅ Loaded: {uploaded_file.name}")
            st.info(f"Shape: {df.shape[0]} rows × {df.shape[1]} columns")
            
            with st.expander("Preview Data"):
                st.dataframe(df.head(10))
        except Exception as e:
            st.error(f"Error loading file: {str(e)}")
    
    st.divider()
    
    if st.session_state.dataset is not None:
        if st.button("🚀 Start Autonomous Analysis", type="primary", use_container_width=True):
            st.session_state.analysis_complete = False
            st.session_state.analysis_results = None
            st.rerun()
    
    st.divider()
    st.markdown("### About")
    st.markdown("""
    This agent uses Claude AI to:
    - Autonomously decide analysis steps
    - Execute Python code dynamically
    - Generate insights iteratively
    """)

# Main content area
if st.session_state.dataset is None:
    st.info("👈 Upload a CSV file to begin")
else:
    # Create tabs
    tab1, tab2, tab3, tab4 = st.tabs(["🤖 Agent Analysis", "💬 Ask Questions", "📊 Interactive Visualizations", "📋 Data Preview"])
    
    with tab1:
        if not st.session_state.analysis_complete:
            if st.button("▶️ Run Analysis") or st.session_state.get('auto_start'):
                st.session_state['auto_start'] = False
                
                with st.spinner("🤖 AI Agent is analyzing your data..."):
                    # Prepare dataset info for the agent
                    dataset_info = {
                        "shape": st.session_state.dataset.shape,
                        "columns": st.session_state.dataset.columns.tolist(),
                        "dtypes": st.session_state.dataset.dtypes.astype(str).to_dict(),
                        "head": st.session_state.dataset.head(5).to_dict(),
                        "describe": st.session_state.dataset.describe().to_dict(),
                        "null_counts": st.session_state.dataset.isnull().sum().to_dict()
                    }
                    
                    # Call the agent
                    import agent_core
                    results = agent_core.run_analysis_agent(
                        st.session_state.dataset,
                        dataset_info
                    )
                    
                    st.session_state.analysis_results = results
                    st.session_state.analysis_complete = True
                    st.rerun()
        
        if st.session_state.analysis_complete and st.session_state.analysis_results:
            results = st.session_state.analysis_results
            
            st.success("✅ Analysis Complete!")
            
            # Display sections
            for section in results.get('sections', []):
                with st.expander(f"📌 {section['title']}", expanded=True):
                    st.markdown(section['content'])
                    
                    # Display charts if available
                    if 'charts' in section:
                        for chart_path in section['charts']:
                            if os.path.exists(chart_path):
                                st.image(chart_path)
            
            # Key insights
            if 'insights' in results:
                st.subheader("💡 Key Insights")
                for insight in results['insights']:
                    st.info(insight)
            
            # Recommendations
            if 'recommendations' in results:
                st.subheader("🎯 Recommendations")
                for rec in results['recommendations']:
                    st.success(rec)
    
    with tab2:
        st.subheader("💬 Ask Questions About Your Data")
        
        # Display chat history
        for message in st.session_state.messages:
            with st.chat_message(message["role"]):
                st.markdown(message["content"])
                if "charts" in message:
                    for chart in message["charts"]:
                        if os.path.exists(chart):
                            st.image(chart)
        
        # Chat input
        if prompt := st.chat_input("Ask a question about your data..."):
            # Add user message
            st.session_state.messages.append({"role": "user", "content": prompt})
            
            with st.chat_message("user"):
                st.markdown(prompt)
            
            # Get AI response
            with st.chat_message("assistant"):
                with st.spinner("Thinking..."):
                    import agent_core
                    response = agent_core.answer_question(
                        st.session_state.dataset,
                        prompt,
                        st.session_state.messages
                    )
                    
                    st.markdown(response['answer'])
                    
                    charts = []
                    if 'charts' in response:
                        for chart_path in response['charts']:
                            if os.path.exists(chart_path):
                                st.image(chart_path)
                                charts.append(chart_path)
                    
                    st.session_state.messages.append({
                        "role": "assistant",
                        "content": response['answer'],
                        "charts": charts
                    })
    
    with tab3:
        st.subheader("📊 Interactive Visualizations")
        st.markdown("Create custom visualizations by selecting chart type and columns")
        
        # Set matplotlib style
        plt.style.use('default')
        sns.set_palette("husl")
        
        # Chart type selector
        chart_type = st.selectbox(
            "Select Chart Type",
            ["Bar Chart", "Line Graph", "Histogram", "Scatter Plot", "Box Plot", "Pie Chart", "Heatmap", "Area Chart"]
        )
        
        # Get numeric and categorical columns
        numeric_cols = st.session_state.dataset.select_dtypes(include=[np.number]).columns.tolist()
        categorical_cols = st.session_state.dataset.select_dtypes(include=['object', 'category']).columns.tolist()
        all_cols = st.session_state.dataset.columns.tolist()
        
        if chart_type == "Bar Chart":
            col1, col2 = st.columns(2)
            with col1:
                x_col = st.selectbox("X-axis (Category)", categorical_cols + numeric_cols)
            with col2:
                y_col = st.selectbox("Y-axis (Value)", numeric_cols)
            
            agg_func = st.selectbox("Aggregation", ["sum", "mean", "count", "median", "min", "max"])
            
            if st.button("Generate Bar Chart", type="primary"):
                fig, ax = plt.subplots(figsize=(10, 6))
                
                if agg_func == "count":
                    data = st.session_state.dataset[x_col].value_counts().sort_index()
                    data.plot(kind='bar', ax=ax, color='steelblue')
                    ax.set_ylabel('Count')
                else:
                    data = st.session_state.dataset.groupby(x_col)[y_col].agg(agg_func).sort_values(ascending=False)
                    data.plot(kind='bar', ax=ax, color='steelblue')
                    ax.set_ylabel(f'{agg_func.capitalize()} of {y_col}')
                
                ax.set_xlabel(x_col)
                ax.set_title(f'{agg_func.capitalize()} of {y_col} by {x_col}')
                ax.tick_params(axis='x', rotation=45)
                plt.tight_layout()
                st.pyplot(fig)
                plt.close()
        
        elif chart_type == "Line Graph":
            col1, col2 = st.columns(2)
            with col1:
                x_col = st.selectbox("X-axis", all_cols)
            with col2:
                y_cols = st.multiselect("Y-axis (can select multiple)", numeric_cols)
            
            if st.button("Generate Line Graph", type="primary") and y_cols:
                fig, ax = plt.subplots(figsize=(12, 6))
                
                for y_col in y_cols:
                    ax.plot(st.session_state.dataset[x_col], st.session_state.dataset[y_col], marker='o', label=y_col, linewidth=2)
                
                ax.set_xlabel(x_col)
                ax.set_ylabel('Value')
                ax.set_title(f'{", ".join(y_cols)} over {x_col}')
                ax.legend()
                ax.grid(True, alpha=0.3)
                plt.xticks(rotation=45)
                plt.tight_layout()
                st.pyplot(fig)
                plt.close()
        
        elif chart_type == "Histogram":
            col1, col2, col3 = st.columns(3)
            with col1:
                hist_col = st.selectbox("Column", numeric_cols)
            with col2:
                bins = st.slider("Number of Bins", 5, 100, 30)
            with col3:
                show_kde = st.checkbox("Show KDE", value=True)
            
            if st.button("Generate Histogram", type="primary"):
                fig, ax = plt.subplots(figsize=(10, 6))
                
                if show_kde:
                    sns.histplot(data=st.session_state.dataset, x=hist_col, bins=bins, kde=True, ax=ax, color='steelblue')
                else:
                    ax.hist(st.session_state.dataset[hist_col].dropna(), bins=bins, color='steelblue', edgecolor='black', alpha=0.7)
                
                ax.set_xlabel(hist_col)
                ax.set_ylabel('Frequency')
                ax.set_title(f'Distribution of {hist_col}')
                ax.grid(True, alpha=0.3)
                plt.tight_layout()
                st.pyplot(fig)
                plt.close()
                
                # Show statistics
                st.markdown("### Statistics")
                col1, col2, col3, col4 = st.columns(4)
                with col1:
                    st.metric("Mean", f"{st.session_state.dataset[hist_col].mean():.2f}")
                with col2:
                    st.metric("Median", f"{st.session_state.dataset[hist_col].median():.2f}")
                with col3:
                    st.metric("Std Dev", f"{st.session_state.dataset[hist_col].std():.2f}")
                with col4:
                    st.metric("Count", f"{st.session_state.dataset[hist_col].count()}")
        
        elif chart_type == "Scatter Plot":
            col1, col2, col3 = st.columns(3)
            with col1:
                x_col = st.selectbox("X-axis", numeric_cols)
            with col2:
                y_col = st.selectbox("Y-axis", numeric_cols)
            with col3:
                color_col = st.selectbox("Color by (optional)", ["None"] + categorical_cols)
            
            show_trend = st.checkbox("Show Trend Line", value=False)
            
            if st.button("Generate Scatter Plot", type="primary"):
                fig, ax = plt.subplots(figsize=(10, 6))
                
                if color_col != "None":
                    for category in st.session_state.dataset[color_col].unique():
                        mask = st.session_state.dataset[color_col] == category
                        ax.scatter(st.session_state.dataset[mask][x_col], 
                                 st.session_state.dataset[mask][y_col], 
                                 label=category, alpha=0.6, s=50)
                    ax.legend()
                else:
                    ax.scatter(st.session_state.dataset[x_col], st.session_state.dataset[y_col], 
                             alpha=0.6, s=50, color='steelblue')
                
                if show_trend:
                    z = np.polyfit(st.session_state.dataset[x_col].dropna(), 
                                  st.session_state.dataset[y_col].dropna(), 1)
                    p = np.poly1d(z)
                    ax.plot(st.session_state.dataset[x_col], p(st.session_state.dataset[x_col]), 
                           "r--", alpha=0.8, linewidth=2, label='Trend')
                    if color_col == "None":
                        ax.legend()
                
                ax.set_xlabel(x_col)
                ax.set_ylabel(y_col)
                ax.set_title(f'{y_col} vs {x_col}')
                ax.grid(True, alpha=0.3)
                plt.tight_layout()
                st.pyplot(fig)
                plt.close()
                
                # Show correlation
                corr = st.session_state.dataset[x_col].corr(st.session_state.dataset[y_col])
                st.metric("Correlation Coefficient", f"{corr:.3f}")
        
        elif chart_type == "Box Plot":
            col1, col2 = st.columns(2)
            with col1:
                y_col = st.selectbox("Value Column", numeric_cols)
            with col2:
                x_col = st.selectbox("Group by (optional)", ["None"] + categorical_cols)
            
            if st.button("Generate Box Plot", type="primary"):
                fig, ax = plt.subplots(figsize=(10, 6))
                
                if x_col != "None":
                    st.session_state.dataset.boxplot(column=y_col, by=x_col, ax=ax, patch_artist=True)
                    ax.set_title(f'Box Plot of {y_col} by {x_col}')
                    ax.set_xlabel(x_col)
                else:
                    st.session_state.dataset.boxplot(column=y_col, ax=ax, patch_artist=True)
                    ax.set_title(f'Box Plot of {y_col}')
                
                ax.set_ylabel(y_col)
                plt.suptitle('')  # Remove default title
                plt.xticks(rotation=45)
                plt.tight_layout()
                st.pyplot(fig)
                plt.close()
        
        elif chart_type == "Pie Chart":
            col1, col2 = st.columns(2)
            with col1:
                cat_col = st.selectbox("Category Column", categorical_cols + numeric_cols)
            with col2:
                top_n = st.slider("Show Top N Categories", 3, 20, 10)
            
            if st.button("Generate Pie Chart", type="primary"):
                fig, ax = plt.subplots(figsize=(10, 8))
                
                data = st.session_state.dataset[cat_col].value_counts().head(top_n)
                colors = sns.color_palette('husl', len(data))
                
                wedges, texts, autotexts = ax.pie(data.values, labels=data.index, autopct='%1.1f%%',
                                                   colors=colors, startangle=90)
                
                for autotext in autotexts:
                    autotext.set_color('white')
                    autotext.set_weight('bold')
                
                ax.set_title(f'Distribution of {cat_col} (Top {top_n})')
                plt.tight_layout()
                st.pyplot(fig)
                plt.close()
        
        elif chart_type == "Heatmap":
            st.markdown("**Correlation Heatmap** - Shows relationships between numeric columns")
            
            cols_to_include = st.multiselect("Select columns (leave empty for all numeric)", numeric_cols, default=numeric_cols[:min(10, len(numeric_cols))])
            
            if st.button("Generate Heatmap", type="primary") and cols_to_include:
                fig, ax = plt.subplots(figsize=(12, 10))
                
                corr_matrix = st.session_state.dataset[cols_to_include].corr()
                
                sns.heatmap(corr_matrix, annot=True, fmt='.2f', cmap='coolwarm', 
                           center=0, square=True, linewidths=1, ax=ax, 
                           cbar_kws={"shrink": 0.8})
                
                ax.set_title('Correlation Heatmap', fontsize=16, pad=20)
                plt.tight_layout()
                st.pyplot(fig)
                plt.close()
        
        elif chart_type == "Area Chart":
            col1, col2 = st.columns(2)
            with col1:
                x_col = st.selectbox("X-axis", all_cols)
            with col2:
                y_cols = st.multiselect("Y-axis (can select multiple)", numeric_cols)
            
            stacked = st.checkbox("Stacked Area", value=False)
            
            if st.button("Generate Area Chart", type="primary") and y_cols:
                fig, ax = plt.subplots(figsize=(12, 6))
                
                if stacked:
                    ax.stackplot(range(len(st.session_state.dataset)), 
                               *[st.session_state.dataset[col] for col in y_cols],
                               labels=y_cols, alpha=0.7)
                else:
                    for y_col in y_cols:
                        ax.fill_between(range(len(st.session_state.dataset)), 
                                      st.session_state.dataset[y_col], 
                                      alpha=0.5, label=y_col)
                
                ax.set_xlabel(x_col)
                ax.set_ylabel('Value')
                ax.set_title(f'Area Chart: {", ".join(y_cols)} over {x_col}')
                ax.legend(loc='upper left')
                ax.grid(True, alpha=0.3)
                plt.tight_layout()
                st.pyplot(fig)
                plt.close()
        
        # Quick visualization suggestions
        st.divider()
        st.markdown("### 💡 Quick Suggestions")
        col1, col2, col3 = st.columns(3)
        
        with col1:
            if st.button("📊 Column Distribution", use_container_width=True):
                st.info(f"Try Histogram with columns: {', '.join(numeric_cols[:3])}")
        
        with col2:
            if st.button("📈 Trends Over Time", use_container_width=True):
                date_cols = [col for col in all_cols if 'date' in col.lower() or 'time' in col.lower()]
                if date_cols:
                    st.info(f"Try Line Graph with X-axis: {date_cols[0]}")
                else:
                    st.info("No date columns detected. Use first column as X-axis.")
        
        with col3:
            if st.button("🔥 Correlations", use_container_width=True):
                st.info("Try Heatmap to see relationships between all numeric columns")
    
    with tab4:
        st.subheader("📊 Dataset Preview")
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Rows", st.session_state.dataset.shape[0])
        with col2:
            st.metric("Columns", st.session_state.dataset.shape[1])
        with col3:
            st.metric("Memory", f"{st.session_state.dataset.memory_usage(deep=True).sum() / 1024:.1f} KB")
        
        st.dataframe(st.session_state.dataset, use_container_width=True, height=400)
        
        with st.expander("📈 Column Statistics"):
            st.dataframe(st.session_state.dataset.describe(), use_container_width=True)
        
        with st.expander("🔍 Data Types & Missing Values"):
            info_df = pd.DataFrame({
                'Column': st.session_state.dataset.columns,
                'Type': st.session_state.dataset.dtypes.astype(str),
                'Missing': st.session_state.dataset.isnull().sum(),
                'Missing %': (st.session_state.dataset.isnull().sum() / len(st.session_state.dataset) * 100).round(2)
            })
            st.dataframe(info_df, use_container_width=True)
