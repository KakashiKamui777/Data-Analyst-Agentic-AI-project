# AI Data Analyst Agent - Architecture & Design

## System Architecture

### High-Level Overview

```
┌──────────────────────────────────────────────────────────┐
│                     User Interface Layer                  │
│                    (Streamlit Web App)                    │
│  - File Upload  - Visualization  - Chat Interface        │
└────────────────────────┬─────────────────────────────────┘
                         │
                         ▼
┌──────────────────────────────────────────────────────────┐
│                    Application Layer                      │
│                       (app.py)                           │
│  - Session Management  - UI Logic  - State Control       │
└────────────────────────┬─────────────────────────────────┘
                         │
                         ▼
┌──────────────────────────────────────────────────────────┐
│                    Agent Layer                            │
│                   (agent_core.py)                         │
│  - Autonomous Planning  - Tool Selection  - Execution    │
└────────────────────────┬─────────────────────────────────┘
                         │
                    ┌────┴────┐
                    ▼         ▼
        ┌──────────────┐  ┌──────────────┐
        │  Claude API  │  │ Python Tools │
        │   (Brain)    │  │ pd, plt, sns │
        └──────────────┘  └──────────────┘
```

## Core Components

### 1. User Interface (app.py)

**Responsibilities:**
- File upload handling
- Tab-based navigation (Analysis, Q&A, Preview)
- Real-time status updates
- Chart rendering
- Session state management

**Key Features:**
- **Sidebar:** Dataset upload, preview, and control
- **Analysis Tab:** Autonomous agent execution and results
- **Q&A Tab:** Interactive chat with the dataset
- **Preview Tab:** Data exploration and statistics

**Session State Variables:**
```python
{
    'messages': [],              # Chat history
    'dataset': DataFrame,        # Uploaded data
    'analysis_complete': bool,   # Analysis status
    'analysis_results': dict     # Cached results
}
```

### 2. Agent Core (agent_core.py)

**Main Functions:**

#### `run_analysis_agent(df, dataset_info)`
The autonomous analysis orchestrator.

**Process:**
1. **Context Building:** Assembles dataset metadata, statistics, and samples
2. **Agent Prompting:** Sends comprehensive prompt to Claude API
3. **Plan Generation:** Receives structured analysis plan in JSON
4. **Code Execution:** Dynamically runs generated Python code
5. **Result Synthesis:** Compiles insights, recommendations, and visualizations

**Input:**
- DataFrame: The dataset to analyze
- dataset_info: Metadata (shape, types, nulls, stats)

**Output:**
```python
{
    'sections': [
        {
            'title': 'Analysis Step Title',
            'content': 'Description and findings',
            'charts': ['path/to/chart.png']
        }
    ],
    'insights': ['Key finding 1', 'Key finding 2'],
    'recommendations': ['Action 1', 'Action 2']
}
```

#### `answer_question(df, question, chat_history)`
Interactive Q&A handler.

**Process:**
1. **Context Assembly:** Recent chat history + dataset summary
2. **Question Processing:** Claude interprets user intent
3. **Code Generation:** Creates Python code if visualization needed
4. **Execution:** Runs code and generates charts
5. **Response Formatting:** Returns answer with visuals

**Input:**
- DataFrame: The dataset
- question: User's natural language query
- chat_history: Previous conversation

**Output:**
```python
{
    'answer': 'Natural language response',
    'charts': ['path/to/generated/chart.png']
}
```

## Agentic Behavior

### What Makes This "Agentic"?

1. **Autonomous Decision-Making**
   - Agent decides which analyses to perform
   - Chooses appropriate statistical methods
   - Determines visualization types
   - No hardcoded analysis pipeline

2. **Dynamic Planning**
   - Creates analysis strategy based on data characteristics
   - Adapts approach for different dataset types
   - Sequences steps logically

3. **Tool Use**
   - Selects Python libraries dynamically
   - Generates custom code for each task
   - Executes code in sandboxed environment

4. **Iterative Reasoning**
   - Each step builds on previous findings
   - Adjusts depth based on data complexity
   - Follows up on interesting patterns

### Agent Workflow

```
┌─────────────────────────┐
│ 1. Receive Dataset      │
│    - Load metadata      │
│    - Inspect structure  │
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│ 2. Analyze Context      │
│    - Data types         │
│    - Distributions      │
│    - Missing values     │
│    - Relationships      │
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│ 3. Plan Strategy        │
│    - Prioritize steps   │
│    - Select methods     │
│    - Design visuals     │
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│ 4. Execute Analysis     │
│    - Generate code      │
│    - Run calculations   │
│    - Create charts      │
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│ 5. Synthesize Insights  │
│    - Interpret results  │
│    - Identify patterns  │
│    - Generate recs      │
└─────────────────────────┘
```

## Data Flow

### Analysis Flow

```
User Uploads CSV
      │
      ▼
Streamlit reads file
      │
      ▼
DataFrame stored in session_state
      │
      ▼
User clicks "Start Analysis"
      │
      ▼
app.py calls agent_core.run_analysis_agent()
      │
      ▼
agent_core builds context & prompt
      │
      ▼
POST request to Claude API
      │
      ▼
Claude returns JSON analysis plan
      │
      ▼
agent_core executes each step's code
      │
      ├─> pandas operations
      ├─> matplotlib charts (saved to outputs/)
      └─> seaborn visualizations
      │
      ▼
Results compiled and returned
      │
      ▼
app.py displays sections & charts
      │
      ▼
User views insights
```

### Q&A Flow

```
User types question
      │
      ▼
app.py captures input
      │
      ▼
Adds to chat history
      │
      ▼
agent_core.answer_question() called
      │
      ▼
Context: question + history + dataset
      │
      ▼
POST request to Claude API
      │
      ▼
Claude analyzes question
      │
      ▼
Generates answer + code (if needed)
      │
      ▼
Code executed locally
      │
      ▼
Charts saved to outputs/
      │
      ▼
Response with charts returned
      │
      ▼
Displayed in chat UI
```

## Code Execution

### Sandboxed Execution

All agent-generated code runs in a controlled namespace:

```python
exec_globals = {
    'pd': pd,           # Pandas
    'plt': plt,         # Matplotlib
    'sns': sns,         # Seaborn
    'df': df,           # The dataset
    'os': os,           # File operations
    'np': numpy         # NumPy
}
```

**Safety Measures:**
- Limited library access
- No network operations
- File writes restricted to outputs/
- Execution timeout implicit

### Chart Generation

Generated code saves visualizations:

```python
plt.figure(figsize=(10, 6))
# ... plotting code ...
plt.savefig('outputs/chart_name.png', dpi=100, bbox_inches='tight')
plt.close()
```

Charts are then referenced in results and displayed in UI.

## API Integration

### Claude API Calls

**Endpoint:** `https://api.anthropic.com/v1/messages`

**Request Structure:**
```python
{
    "model": "claude-sonnet-4-20250514",
    "max_tokens": 4000,
    "messages": [
        {
            "role": "user",
            "content": "Analysis prompt with dataset info"
        }
    ]
}
```

**Response Parsing:**
```python
data = response.json()
for content in data.get('content', []):
    if content.get('type') == 'text':
        response_text += content.get('text', '')
```

### Prompt Engineering

**Analysis Prompt Structure:**
1. **Role Definition:** "You are an expert data analyst agent"
2. **Dataset Context:** Shape, columns, types, samples, statistics
3. **Task Description:** Multi-step autonomous analysis
4. **Output Format:** JSON with structured plan
5. **Constraints:** Available libraries, file paths

**Q&A Prompt Structure:**
1. **Role Definition:** "You are a data analyst assistant"
2. **Dataset Summary:** Key metadata and samples
3. **Conversation History:** Last 5 messages
4. **User Question:** Current query
5. **Output Format:** JSON with answer and optional code

## State Management

### Streamlit Session State

```python
if 'messages' not in st.session_state:
    st.session_state.messages = []

if 'dataset' not in st.session_state:
    st.session_state.dataset = None

if 'analysis_complete' not in st.session_state:
    st.session_state.analysis_complete = False

if 'analysis_results' not in st.session_state:
    st.session_state.analysis_results = None
```

**Persistence:** Data persists across reruns within same session

**Scope:** Isolated per user session (multi-user safe)

## Visualization Pipeline

### Chart Creation Flow

1. **Agent Decides:** Determines chart type needed
2. **Code Generation:** Creates matplotlib/seaborn code
3. **Execution:** Runs code with dataset
4. **File Save:** Writes PNG to outputs/
5. **Path Return:** Includes path in results
6. **UI Display:** Streamlit renders image

### Supported Chart Types

- Line plots (time series)
- Bar charts (categorical comparisons)
- Histograms (distributions)
- Box plots (outlier detection)
- Scatter plots (correlations)
- Heatmaps (correlation matrices)
- Pie charts (proportions)
- Pair plots (multi-variable relationships)

## Error Handling

### Graceful Degradation

**File Upload Errors:**
```python
try:
    df = pd.read_csv(uploaded_file)
except Exception as e:
    st.error(f"Error loading file: {str(e)}")
```

**Code Execution Errors:**
```python
try:
    exec(code, exec_globals, exec_locals)
except Exception as e:
    section['content'] += f"\n\n⚠️ Error: {str(e)}"
```

**JSON Parsing Errors:**
```python
try:
    analysis_plan = json.loads(response_text)
except json.JSONDecodeError:
    # Fallback to basic analysis
    analysis_plan = default_plan
```

**API Errors:**
- Network issues: Display user-friendly message
- Rate limits: Suggest retry
- Invalid responses: Use fallback analysis

## Performance Considerations

### Optimization Strategies

1. **Lazy Loading:** Charts generated only when viewed
2. **Caching:** Analysis results cached in session state
3. **Streaming:** Could implement streaming for long analyses
4. **Pagination:** Large datasets could be sampled for preview

### Scalability

**Current Limits:**
- CSV size: Depends on memory
- Analysis time: ~10-30 seconds typical
- Charts: Stored temporarily per session

**Future Enhancements:**
- Background processing
- Progressive result streaming
- Database backend for large datasets
- Multi-file support

## Security

### Data Privacy

- **Local Processing:** CSV data stays in user session
- **No Storage:** No persistent database
- **API Only:** Only metadata sent to Claude
- **Session Isolation:** Multi-user safe

### Code Safety

- **Sandboxed Execution:** Limited library access
- **No Network Calls:** Code can't access external resources
- **File Restrictions:** Writes only to outputs/
- **Input Validation:** File type checking

## Extension Points

### Adding New Capabilities

**1. New Analysis Types:**
```python
# In agent_core.py, extend the prompt
"You can also perform:
- Time series forecasting
- Clustering analysis
- Statistical tests"
```

**2. New Libraries:**
```python
exec_globals = {
    # ... existing ...
    'scipy': __import__('scipy'),
    'sklearn': __import__('sklearn'),
}
```

**3. New Visualizations:**
```python
# Agent can use plotly for interactive charts
'plotly': __import__('plotly.express')
```

**4. Export Features:**
```python
def export_report(results):
    # Generate PDF/Word report
    # Include charts and insights
    # Offer download
```

## Testing Strategy

### Component Tests

**test_agent.py** verifies:
- Import availability
- Sample data loading
- Agent core functions
- App structure

**Manual Testing:**
- Various dataset types
- Edge cases (missing data, outliers)
- Different question types
- UI responsiveness

### Future Testing

- Unit tests for agent logic
- Integration tests for API calls
- UI tests with Selenium
- Performance benchmarks

## Deployment

### Local Development
```bash
streamlit run app.py
```

### Production Deployment

**Options:**
1. **Streamlit Cloud:** Direct GitHub integration
2. **Docker:** Containerize application
3. **Cloud Platforms:** AWS, GCP, Azure
4. **Self-Hosted:** VPS with reverse proxy

**Requirements:**
- Python 3.8+
- API access configured
- Dependencies installed

## Monitoring

### Metrics to Track

- Analysis completion rate
- Average processing time
- Error frequency
- User engagement
- Chart generation success

### Logging

Currently basic Python logging. Could enhance with:
- Structured logging (JSON)
- Log aggregation (ELK, CloudWatch)
- Performance tracing
- User analytics

---

## Summary

This AI Data Analyst Agent demonstrates true agentic behavior through:

1. **Autonomous Decision-Making:** No hardcoded analysis flow
2. **Dynamic Tool Use:** Generates and executes code on-demand
3. **Iterative Reasoning:** Builds analysis layer by layer
4. **Natural Interaction:** Conversational Q&A interface

The architecture separates concerns cleanly:
- **UI Layer:** Streamlit handles user interaction
- **Application Layer:** Manages state and orchestration
- **Agent Layer:** Implements autonomous intelligence
- **Execution Layer:** Runs generated analysis code

This design allows for easy extension, testing, and deployment while maintaining security and performance.
