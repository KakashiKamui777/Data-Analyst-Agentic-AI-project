# 🤖 AI Data Analyst Agent

An autonomous AI-powered data analyst that uses Claude API to intelligently analyze datasets, generate insights, and answer questions.

## 🎯 Features

### Autonomous Analysis
- **Smart Data Cleaning**: Automatically identifies and handles missing values, outliers, and data quality issues
- **Exploratory Data Analysis (EDA)**: Performs comprehensive statistical analysis
- **Pattern Recognition**: Identifies trends, correlations, and anomalies
- **Insight Generation**: Produces actionable business insights
- **Auto Visualization**: Creates relevant charts and graphs

### Interactive Visualizations (NEW!)
- **8 Chart Types**: Bar Chart, Line Graph, Histogram, Scatter Plot, Box Plot, Pie Chart, Heatmap, Area Chart
- **No-Code Interface**: Create custom visualizations with dropdown menus
- **Real-Time Preview**: See charts instantly as you configure them
- **Statistical Insights**: Automatic statistics and correlation calculations
- **Smart Suggestions**: Quick buttons for common visualization patterns
- **Export Ready**: High-resolution charts ready for presentations

### Agentic Behavior
- **Dynamic Decision Making**: Agent decides which analyses to perform based on data characteristics
- **Iterative Learning**: Builds on previous analysis steps
- **Tool Selection**: Autonomously chooses appropriate Python libraries and methods
- **Self-Directed**: No predefined analysis pipeline - adapts to each dataset

### Interactive Q&A
- Ask questions in natural language
- Get code-backed answers with visualizations
- Maintains conversation context
- Generates custom analysis on demand

## 🛠️ Tech Stack

- **Frontend**: Streamlit (Interactive web UI)
- **AI Engine**: Claude 4 Sonnet API (Anthropic)
- **Data Processing**: Pandas, NumPy
- **Visualization**: Matplotlib, Seaborn
- **Architecture**: Agentic AI with autonomous decision-making

## 📋 Prerequisites

- Python 3.8+
- Claude API access (automatically configured in this environment)

## 🚀 Installation

1. **Install dependencies**:
```bash
pip install -r requirements.txt
```

2. **Run the application**:
```bash
streamlit run app.py
```

3. **Access the UI**:
   - The app will open in your browser automatically
   - Or navigate to `http://localhost:8501`

## 📊 Usage

### Quick Start

1. **Upload Dataset**:
   - Click "Browse files" in the sidebar
   - Upload any CSV file (sample provided: `sample_sales_data.csv`)

2. **Autonomous Analysis**:
   - Click "🚀 Start Autonomous Analysis"
   - Watch the agent work through data cleaning, EDA, and insights
   - Review generated visualizations and recommendations

3. **Interactive Visualizations** (NEW!):
   - Switch to "📊 Interactive Visualizations" tab
   - Select chart type (Bar, Line, Histogram, Scatter, Box, Pie, Heatmap, Area)
   - Choose columns and parameters
   - Generate custom visualizations instantly
   - See VISUALIZATION_GUIDE.md for detailed instructions

4. **Ask Questions**:
   - Switch to "💬 Ask Questions" tab
   - Type natural language questions like:
     - "What are the top-selling products?"
     - "Show me sales trends over time"
     - "Which region has the highest profit margin?"
     - "Create a correlation heatmap"

### Example Datasets

**Included: sample_sales_data.csv**
- Sales transactions with products, categories, regions
- Perfect for testing business analytics capabilities

**Try your own data**:
- Customer data
- Financial records
- Survey responses
- Time series data
- Any tabular CSV data

## 🧠 How It Works

### Agent Architecture

```
┌─────────────────────────────────────────┐
│         User Uploads Dataset            │
└────────────────┬────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────┐
│   Agent Analyzes Dataset Characteristics│
│   - Shape, types, distributions         │
│   - Missing values, outliers            │
│   - Statistical properties              │
└────────────────┬────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────┐
│   Agent Plans Analysis Strategy         │
│   - Decides which analyses to run       │
│   - Determines visualization types      │
│   - Prioritizes insights                │
└────────────────┬────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────┐
│   Agent Executes Analysis Steps         │
│   - Runs Python code dynamically        │
│   - Generates charts with matplotlib    │
│   - Interprets results                  │
└────────────────┬────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────┐
│   Agent Synthesizes Insights            │
│   - Identifies key findings             │
│   - Provides recommendations            │
│   - Answers follow-up questions         │
└─────────────────────────────────────────┘
```

### Key Components

**1. app.py** - Streamlit UI
- File upload interface
- Tab-based navigation
- Real-time agent status
- Chart rendering

**2. agent_core.py** - AI Agent Brain
- `run_analysis_agent()`: Autonomous analysis orchestrator
- `answer_question()`: Interactive Q&A handler
- Claude API integration
- Dynamic code execution

**3. Agentic Workflow**
- Agent receives dataset metadata
- Plans analysis strategy autonomously
- Generates and executes Python code
- Iterates based on findings
- Produces insights and visualizations

## 🎨 Example Analyses

The agent can autonomously perform:

- **Data Quality Assessment**
  - Missing value analysis
  - Duplicate detection
  - Outlier identification

- **Descriptive Statistics**
  - Central tendency measures
  - Distribution analysis
  - Variance and spread

- **Visual Analytics**
  - Time series plots
  - Distribution histograms
  - Correlation heatmaps
  - Category comparisons
  - Geographic analysis

- **Advanced Insights**
  - Trend detection
  - Segment analysis
  - Predictive indicators
  - Anomaly detection

## 💡 Example Questions to Ask

```
"What's the average sales by category?"
"Show me the distribution of profits"
"Which products have declining sales?"
"Create a pivot table of sales by region and product"
"Are there any seasonal patterns?"
"What's the correlation between discount and profit?"
"Show me the top 10 customers by revenue"
"Which region underperforms and why?"
```

## 🔧 Customization

### Modify Agent Behavior

Edit `agent_core.py` to customize:
- Analysis depth and breadth
- Visualization styles
- Insight generation logic
- Code execution sandbox

### Add Analysis Capabilities

Extend the agent's toolset:
```python
# In agent_core.py
exec_globals = {
    'pd': pd,
    'plt': plt,
    'sns': sns,
    'df': df,
    # Add more libraries:
    'scipy': __import__('scipy'),
    'sklearn': __import__('sklearn'),
}
```

### UI Customization

Modify `app.py` for:
- Custom themes
- Additional tabs
- Export options
- Sharing features

## 🎯 Use Cases

- **Business Analytics**: Sales analysis, customer segmentation, KPI tracking
- **Data Science**: Quick EDA, hypothesis generation, feature exploration
- **Research**: Survey analysis, experimental data review
- **Finance**: Portfolio analysis, risk assessment, trend identification
- **Marketing**: Campaign performance, A/B test analysis, customer insights

## 🔒 Security Notes

- Data processed locally in your environment
- API calls to Claude are secure
- No data stored permanently
- CSV files processed in-memory

## 📈 Future Enhancements

- [ ] Multi-file dataset support
- [ ] Export analysis reports (PDF/Word)
- [ ] Database connectivity (SQL, NoSQL)
- [ ] Time series forecasting
- [ ] Machine learning model suggestions
- [ ] Automated report scheduling
- [ ] Collaboration features

## 🤝 Contributing

This is a demonstration project showing agentic AI capabilities. Feel free to:
- Extend analysis types
- Add new visualizations
- Improve agent reasoning
- Optimize performance

## 📝 License

MIT License - Use freely for learning and projects

## 🙋 Support

Issues with:
- **Data loading**: Check CSV format, encoding
- **Analysis errors**: Review dataset for edge cases
- **API errors**: Verify Claude API access

## 🎓 Learning Resources

**Agentic AI Concepts**:
- Tool use and function calling
- Dynamic code generation
- Autonomous decision-making
- Multi-step reasoning

**Technologies**:
- Streamlit documentation
- Pandas user guide
- Claude API reference
- Matplotlib gallery

---

Built with ❤️ using Claude AI - Demonstrating the power of agentic AI for data analysis
