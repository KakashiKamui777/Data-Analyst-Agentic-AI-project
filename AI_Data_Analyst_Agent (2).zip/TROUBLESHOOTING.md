# 🔧 Troubleshooting Guide

## Common Issues & Solutions

### Issue 1: Agent Not Responding in "Ask Questions" Tab

**Symptoms:**
- You type a question and press Enter
- Nothing happens or loading spinner doesn't stop
- No response appears

**Solutions:**

#### Solution A: Check if App is Running
```bash
# Make sure Streamlit is running
# You should see in terminal:
# "You can now view your Streamlit app in your browser"
# "Local URL: http://localhost:8501"
```

#### Solution B: Refresh the Page
1. Press `Ctrl+R` (or `Cmd+R` on Mac)
2. Or click the refresh button in your browser
3. Upload the dataset again
4. Try your question

#### Solution C: Check Browser Console
1. Press `F12` to open Developer Tools
2. Click "Console" tab
3. Look for any error messages
4. Take a screenshot and check the error

#### Solution D: Restart the App
```bash
# In terminal where app is running:
# Press Ctrl+C to stop

# Then restart:
streamlit run app.py
```

---

### Issue 2: API Connection Error

**Symptoms:**
- Error message about API connection
- "Unable to reach Claude API"
- Request timeout errors

**Solution:**

The app now has **fallback mode** that works WITHOUT the API!

**What works in fallback mode:**
- ✅ Top N products queries
- ✅ Total sales calculations
- ✅ Average/mean calculations
- ✅ Sales trend visualizations
- ✅ Basic statistics

**Example questions that work:**
```
What are the top 5 products by sales?
What's the total sales?
What's the average profit?
Show me sales trends over time
```

**If you see a helpful suggestion message**, the fallback is working! Just try one of the suggested questions.

---

### Issue 3: Charts Not Displaying

**Symptoms:**
- Text answer appears but no chart
- "Chart not found" message

**Solutions:**

#### Solution A: Check outputs folder
```bash
# In your project folder:
ls outputs/

# Should show .png files
# If folder doesn't exist:
mkdir outputs
```

#### Solution B: Try a simpler chart request
```
Create a bar chart of sales by product
```

#### Solution C: Use Interactive Visualizations Tab
1. Go to "📊 Interactive Visualizations" tab
2. Select chart type
3. Choose columns
4. Click "Generate"

This bypasses the AI and creates charts directly!

---

### Issue 4: "Module Not Found" Error

**Symptoms:**
```
ModuleNotFoundError: No module named 'streamlit'
```

**Solution:**
```bash
# Make sure virtual environment is activated
# You should see (venv) in your terminal prompt

# If not activated:
source venv/bin/activate  # Mac/Linux
venv\Scripts\activate     # Windows

# Reinstall dependencies:
pip install -r requirements.txt
```

---

### Issue 5: Port Already in Use

**Symptoms:**
```
OSError: [Errno 48] Address already in use
```

**Solution:**
```bash
# Option 1: Use different port
streamlit run app.py --server.port 8502

# Option 2: Kill existing process
# On Mac/Linux:
lsof -ti:8501 | xargs kill -9

# On Windows:
netstat -ano | findstr :8501
taskkill /PID <PID_NUMBER> /F
```

---

### Issue 6: CSV Upload Fails

**Symptoms:**
- "Error loading file"
- Upload doesn't work

**Solutions:**

#### Check CSV format:
```
✓ First row should be headers
✓ No empty rows at top
✓ Consistent columns in every row
✓ UTF-8 encoding
```

#### Try the sample file first:
```
Upload: sample_sales_data.csv
(Included in the project)
```

#### Convert Excel to CSV:
```
In Excel:
File → Save As → CSV (UTF-8)
```

---

### Issue 7: Slow Performance

**Symptoms:**
- App takes long time to load
- Questions take >30 seconds
- Charts render slowly

**Solutions:**

#### For large datasets:
```python
# Sample your data first
# Add this to top of app.py (for testing):

if st.session_state.dataset is not None:
    if len(st.session_state.dataset) > 10000:
        st.session_state.dataset = st.session_state.dataset.sample(10000)
        st.warning("Large dataset detected - using 10,000 row sample")
```

#### Close other browser tabs

#### Use Chrome or Firefox
(Safari can be slower with Streamlit)

---

### Issue 8: Virtual Environment Issues

**Symptoms:**
```
command not found: streamlit
```

**Solution:**
```bash
# Check if venv is activated:
which python
# Should show: /path/to/your/project/venv/bin/python

# If not, activate it:
source venv/bin/activate  # Mac/Linux
venv\Scripts\activate     # Windows

# You should see (venv) in your prompt:
(venv) user@computer:~/project$
```

---

## 🎯 Quick Diagnostic

Run this to check everything:

```bash
# 1. Check Python version
python --version
# Should be 3.8 or higher

# 2. Check if dependencies installed
pip list | grep streamlit
pip list | grep pandas

# 3. Check if files exist
ls app.py agent_core.py requirements.txt

# 4. Run test script
python test_agent.py

# 5. Try starting the app
streamlit run app.py
```

---

## 💡 What Should Work Right Now

Even if the Claude API isn't working, these features ALWAYS work:

### ✅ **Interactive Visualizations Tab**
- All 8 chart types
- No API needed
- Point-and-click interface

### ✅ **Data Preview Tab**
- View your data
- See statistics
- Check data types
- Find missing values

### ✅ **Basic Q&A (Fallback Mode)**
- Top N products
- Total/average calculations
- Simple trend charts

---

## 🔍 Specific Error Messages

### "Connection refused"
```
Solution: Check if app is running on port 8501
```

### "API key not found"
```
Solution: This is expected - fallback mode will activate
```

### "df is not defined"
```
Solution: Make sure dataset is uploaded first
```

### "No module named 'X'"
```
Solution: pip install -r requirements.txt
```

### "Permission denied"
```
Solution: chmod +x run.sh (on Mac/Linux)
```

---

## 🚨 Emergency Reset

If nothing works:

```bash
# 1. Delete virtual environment
rm -rf venv

# 2. Recreate it
python3 -m venv venv

# 3. Activate
source venv/bin/activate

# 4. Reinstall
pip install -r requirements.txt

# 5. Run
streamlit run app.py
```

---

## 📞 Still Having Issues?

### Check These:

1. ✅ Is Python 3.8+ installed?
   ```bash
   python --version
   ```

2. ✅ Is virtual environment activated?
   ```bash
   # You should see (venv) in prompt
   ```

3. ✅ Are dependencies installed?
   ```bash
   pip list
   ```

4. ✅ Is the app running?
   ```bash
   # Should see "You can now view..."
   ```

5. ✅ Is browser pointing to correct URL?
   ```
   http://localhost:8501
   ```

---

## 💬 Testing the Ask Questions Feature

### Step-by-Step Test:

1. **Start app**: `streamlit run app.py`
2. **Upload**: `sample_sales_data.csv`
3. **Go to**: "💬 Ask Questions" tab
4. **Type**: `What are the top 5 products by sales?`
5. **Press**: Enter

**Expected Result:**
```
🤖 Assistant:
Here are the top 5 products by total sales:

1. Laptop - $5,930
2. Phone - $3,280
3. Monitor - $1,450
4. Table - $1,910
5. Desk - $1,840

[Bar chart appears]
```

**If you get a "helpful suggestions" message instead:**
- Fallback mode is active
- This is normal!
- The suggested questions will work

---

## 🎉 Success Checklist

Your app is working correctly if:

- ✅ App loads at http://localhost:8501
- ✅ Can upload CSV files
- ✅ See data preview in sidebar
- ✅ Can create charts in Interactive Visualizations tab
- ✅ Get responses in Ask Questions tab (with or without API)
- ✅ Charts display properly

---

## 🔄 Version Differences

### If using the original version:
- Requires Claude API access
- May fail silently if API unavailable

### If using the updated version (v2.0+):
- Has fallback mode
- Works WITHOUT API for common questions
- Better error messages
- More reliable

**Check your version:**
Look for `handle_question_locally` function in `agent_core.py`
- If present: You have v2.0+ (better!)
- If not: Re-download the latest zip file

---

## 📥 Get the Fixed Version

The latest version includes:
- ✅ Fallback mode for offline use
- ✅ Better error handling
- ✅ Helpful error messages
- ✅ More robust question handling

Download the updated zip file from this conversation!

---

Remember: The **Interactive Visualizations tab** ALWAYS works, even without API access. Use it as a reliable fallback! 📊
