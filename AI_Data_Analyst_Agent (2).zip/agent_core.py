import os
import json
import pandas as pd
from datetime import datetime
import asyncio

def run_analysis_agent(df, dataset_info):
    """
    Main agent that autonomously analyzes the dataset
    """
    
    # Create output directory for charts
    os.makedirs("outputs", exist_ok=True)
    
    # Build the prompt for autonomous analysis
    prompt = f"""You are an expert data analyst agent. Analyze this dataset autonomously and provide comprehensive insights.

Dataset Information:
- Shape: {dataset_info['shape'][0]} rows × {dataset_info['shape'][1]} columns
- Columns: {', '.join(dataset_info['columns'])}
- Data Types: {json.dumps(dataset_info['dtypes'], indent=2)}
- Missing Values: {json.dumps(dataset_info['null_counts'], indent=2)}

First 5 rows:
{json.dumps(dataset_info['head'], indent=2)}

Statistical Summary:
{json.dumps(dataset_info['describe'], indent=2)}

Your task is to:
1. Assess data quality and identify cleaning needs
2. Perform exploratory data analysis (EDA)
3. Identify patterns, trends, and anomalies
4. Generate actionable insights
5. Create visualizations to support findings

Think step by step and decide what analyses to perform. For each analysis step, provide:
- The analysis to perform
- Python code to execute
- Interpretation of results

Respond in JSON format with this structure:
{{
  "analysis_plan": ["step 1", "step 2", ...],
  "steps": [
    {{
      "title": "Step title",
      "description": "What this step does",
      "code": "Python code to execute",
      "interpretation": "How to interpret results"
    }}
  ],
  "insights": ["insight 1", "insight 2", ...],
  "recommendations": ["recommendation 1", "recommendation 2", ...]
}}

Use pandas (imported as pd), matplotlib.pyplot (as plt), and seaborn (as sns) in your code.
Save all plots to 'outputs/' directory with descriptive names.
"""

    # Call Claude API
    import requests
    
    response = requests.post(
        "https://api.anthropic.com/v1/messages",
        headers={"Content-Type": "application/json"},
        json={
            "model": "claude-sonnet-4-20250514",
            "max_tokens": 4000,
            "messages": [
                {
                    "role": "user",
                    "content": prompt
                }
            ]
        }
    )
    
    data = response.json()
    
    # Extract response
    response_text = ""
    for content in data.get('content', []):
        if content.get('type') == 'text':
            response_text += content.get('text', '')
    
    # Parse JSON response
    try:
        # Remove markdown code blocks if present
        response_text = response_text.strip()
        if response_text.startswith('```json'):
            response_text = response_text[7:]
        if response_text.startswith('```'):
            response_text = response_text[3:]
        if response_text.endswith('```'):
            response_text = response_text[:-3]
        response_text = response_text.strip()
        
        analysis_plan = json.loads(response_text)
    except json.JSONDecodeError:
        # Fallback if JSON parsing fails
        analysis_plan = {
            "analysis_plan": ["Data overview", "Basic statistics"],
            "steps": [],
            "insights": ["Analysis completed with basic overview"],
            "recommendations": ["Review the data for further analysis"]
        }
    
    # Execute the analysis steps
    results = {
        "sections": [],
        "insights": analysis_plan.get('insights', []),
        "recommendations": analysis_plan.get('recommendations', [])
    }
    
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import seaborn as sns
    
    # Set style
    sns.set_style("whitegrid")
    plt.rcParams['figure.figsize'] = (10, 6)
    
    for i, step in enumerate(analysis_plan.get('steps', [])):
        section = {
            "title": step.get('title', f'Analysis Step {i+1}'),
            "content": step.get('description', ''),
            "charts": []
        }
        
        # Execute code
        code = step.get('code', '')
        if code:
            try:
                # Create execution namespace
                exec_globals = {
                    'pd': pd,
                    'plt': plt,
                    'sns': sns,
                    'df': df,
                    'os': os,
                    'np': __import__('numpy')
                }
                exec_locals = {}
                
                # Execute the code
                exec(code, exec_globals, exec_locals)
                
                # Find any saved charts
                if os.path.exists('outputs'):
                    charts = [f"outputs/{f}" for f in os.listdir('outputs') if f.endswith(('.png', '.jpg', '.jpeg'))]
                    # Get only new charts for this step
                    section['charts'] = charts[-1:] if charts else []
                
                # Add interpretation
                if step.get('interpretation'):
                    section['content'] += f"\n\n**Interpretation:** {step['interpretation']}"
                
            except Exception as e:
                section['content'] += f"\n\n⚠️ Error executing analysis: {str(e)}"
        
        results['sections'].append(section)
    
    return results


def answer_question(df, question, chat_history):
    """
    Answer specific questions about the dataset
    """
    
    # Build context from chat history
    context = ""
    for msg in chat_history[-5:]:  # Last 5 messages
        role = msg['role']
        content = msg['content']
        context += f"{role}: {content}\n"
    
    # Dataset summary
    dataset_summary = f"""
Dataset shape: {df.shape[0]} rows × {df.shape[1]} columns
Columns: {', '.join(df.columns.tolist())}
Data types: {df.dtypes.to_dict()}

First few rows:
{df.head(3).to_string()}
"""
    
    prompt = f"""You are a data analyst assistant. Answer the user's question about their dataset.

{dataset_summary}

Previous conversation:
{context}

User question: {question}

If the question requires analysis or visualization:
1. Provide a clear answer
2. Include Python code to generate visualizations if helpful
3. Save plots to 'outputs/question_{{timestamp}}.png'

Respond in JSON format:
{{
  "answer": "Your detailed answer here",
  "requires_code": true/false,
  "code": "Python code if needed"
}}

Use pandas (pd), matplotlib.pyplot (plt), and seaborn (sns).
"""
    
    import requests
    
    try:
        response = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers={"Content-Type": "application/json"},
            json={
                "model": "claude-sonnet-4-20250514",
                "max_tokens": 2000,
                "messages": [
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            },
            timeout=30
        )
        
        response.raise_for_status()
        data = response.json()
        
        # Extract response
        response_text = ""
        for content in data.get('content', []):
            if content.get('type') == 'text':
                response_text += content.get('text', '')
        
        # Parse response
        try:
            response_text = response_text.strip()
            if response_text.startswith('```json'):
                response_text = response_text[7:]
            if response_text.startswith('```'):
                response_text = response_text[3:]
            if response_text.endswith('```'):
                response_text = response_text[:-3]
            response_text = response_text.strip()
            
            result = json.loads(response_text)
        except:
            result = {
                "answer": response_text,
                "requires_code": False
            }
        
        # Execute code if provided
        charts = []
        if result.get('requires_code') and result.get('code'):
            try:
                import matplotlib
                matplotlib.use('Agg')
                import matplotlib.pyplot as plt
                import seaborn as sns
                
                exec_globals = {
                    'pd': pd,
                    'plt': plt,
                    'sns': sns,
                    'df': df,
                    'os': os,
                    'np': __import__('numpy'),
                    'datetime': datetime
                }
                
                exec(result['code'], exec_globals)
                
                # Find generated charts
                if os.path.exists('outputs'):
                    all_charts = [f"outputs/{f}" for f in os.listdir('outputs') if f.endswith(('.png', '.jpg', '.jpeg'))]
                    # Get most recent chart
                    if all_charts:
                        charts = [max(all_charts, key=os.path.getctime)]
            except Exception as e:
                result['answer'] += f"\n\n⚠️ Error generating visualization: {str(e)}"
        
        return {
            "answer": result.get('answer', 'Unable to process question'),
            "charts": charts
        }
        
    except requests.exceptions.RequestException as e:
        # API call failed - provide fallback answer
        return handle_question_locally(df, question)
    except Exception as e:
        return {
            "answer": f"Error processing question: {str(e)}. Please try rephrasing your question.",
            "charts": []
        }


def handle_question_locally(df, question):
    """
    Fallback handler for common questions when API is unavailable
    """
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import seaborn as sns
    import numpy as np
    
    question_lower = question.lower()
    charts = []
    
    # Top N products
    if 'top' in question_lower and 'product' in question_lower:
        try:
            n = 5
            if '10' in question: n = 10
            elif '3' in question: n = 3
            
            top_products = df.groupby('Product')['Sales'].sum().sort_values(ascending=False).head(n)
            
            # Create chart
            os.makedirs('outputs', exist_ok=True)
            fig, ax = plt.subplots(figsize=(10, 6))
            top_products.plot(kind='bar', ax=ax, color='steelblue')
            ax.set_title(f'Top {n} Products by Sales')
            ax.set_ylabel('Total Sales ($)')
            ax.set_xlabel('Product')
            plt.xticks(rotation=45)
            plt.tight_layout()
            plt.savefig('outputs/top_products.png', dpi=100, bbox_inches='tight')
            plt.close()
            charts.append('outputs/top_products.png')
            
            answer = f"Here are the top {n} products by total sales:\n\n"
            for i, (product, sales) in enumerate(top_products.items(), 1):
                answer += f"{i}. {product} - ${sales:,.0f}\n"
            
            return {"answer": answer, "charts": charts}
        except Exception as e:
            return {"answer": f"Error analyzing products: {str(e)}", "charts": []}
    
    # Total sales
    elif 'total' in question_lower and 'sales' in question_lower:
        total = df['Sales'].sum()
        return {"answer": f"The total sales across all transactions is ${total:,.2f}.", "charts": []}
    
    # Average
    elif 'average' in question_lower or 'mean' in question_lower:
        if 'sales' in question_lower:
            avg = df['Sales'].mean()
            return {"answer": f"The average sales value is ${avg:,.2f}.", "charts": []}
        elif 'profit' in question_lower:
            avg = df['Profit'].mean()
            return {"answer": f"The average profit is ${avg:,.2f}.", "charts": []}
    
    # Trends
    elif 'trend' in question_lower or 'over time' in question_lower:
        try:
            os.makedirs('outputs', exist_ok=True)
            
            # Try to find date column
            date_col = None
            for col in df.columns:
                if 'date' in col.lower() or 'time' in col.lower():
                    date_col = col
                    break
            
            if date_col:
                df_copy = df.copy()
                df_copy[date_col] = pd.to_datetime(df_copy[date_col])
                daily_sales = df_copy.groupby(date_col)['Sales'].sum().sort_index()
                
                fig, ax = plt.subplots(figsize=(12, 6))
                ax.plot(daily_sales.index, daily_sales.values, marker='o', linewidth=2, color='steelblue')
                ax.set_title('Sales Trend Over Time')
                ax.set_xlabel('Date')
                ax.set_ylabel('Sales ($)')
                ax.grid(True, alpha=0.3)
                plt.xticks(rotation=45)
                plt.tight_layout()
                plt.savefig('outputs/sales_trend.png', dpi=100, bbox_inches='tight')
                plt.close()
                charts.append('outputs/sales_trend.png')
                
                return {"answer": "Here's the sales trend over time. The data shows the daily sales pattern across the dataset period.", "charts": charts}
        except Exception as e:
            pass
    
    # Default response
    return {
        "answer": "I can help you analyze this dataset! Try asking:\n\n" +
                 "• What are the top 5 products by sales?\n" +
                 "• What's the total sales?\n" +
                 "• Show me sales trends over time\n" +
                 "• Create a bar chart of sales by category\n\n" +
                 "Or check the QUESTIONS_GUIDE.md for 100+ example questions!",
        "charts": []
    }
